import express from 'express';
import { supabaseAdmin } from '../config/supabase.js';

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password, and name are required' });
    }

    if (!email.endsWith('@srmp.edu.in')) {
      return res.status(400).json({ error: 'Only SRM University AP students with @srmp.edu.in email can register' });
    }

    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true
    });

    if (authError) {
      return res.status(400).json({ error: authError.message });
    }

    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .insert([
        {
          id: authData.user.id,
          email,
          name,
          year: ''
        }
      ]);

    if (profileError) {
      await supabaseAdmin.auth.admin.deleteUser(authData.user.id);
      return res.status(400).json({ error: 'Failed to create profile' });
    }

    res.json({ message: 'Registration successful', user: authData.user });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
