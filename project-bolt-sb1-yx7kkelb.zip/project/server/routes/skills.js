import express from 'express';
import { supabaseAdmin } from '../config/supabase.js';

const router = express.Router();

router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const { data, error } = await supabaseAdmin
      .from('skills')
      .select('*')
      .eq('user_id', userId);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { userId, skillName } = req.body;

    if (!userId || !skillName) {
      return res.status(400).json({ error: 'User ID and skill name are required' });
    }

    const { data, error } = await supabaseAdmin
      .from('skills')
      .insert([
        {
          user_id: userId,
          skill_name: skillName
        }
      ])
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:skillId', async (req, res) => {
  try {
    const { skillId } = req.params;

    const { error } = await supabaseAdmin
      .from('skills')
      .delete()
      .eq('id', skillId);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Skill deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/search', async (req, res) => {
  try {
    const { query } = req.query;

    if (!query) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    const { data: skills, error: skillsError } = await supabaseAdmin
      .from('skills')
      .select('*, profiles(*)')
      .ilike('skill_name', `%${query}%`);

    if (skillsError) {
      return res.status(400).json({ error: skillsError.message });
    }

    const uniqueUsers = new Map();
    skills.forEach(skill => {
      const userId = skill.user_id;
      if (!uniqueUsers.has(userId)) {
        uniqueUsers.set(userId, {
          ...skill.profiles,
          skills: []
        });
      }
      uniqueUsers.get(userId).skills.push(skill.skill_name);
    });

    const results = Array.from(uniqueUsers.values());

    res.json(results);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
