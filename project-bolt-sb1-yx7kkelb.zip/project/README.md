# SRM SkillX - Skill Swap Platform

A full-stack web application for SRM University AP students to share and discover skills. Built with modern web technologies and Supabase for backend services.

## Features

- **Exclusive Access**: Only students with @srmp.edu.in email can register
- **Secure Authentication**: Email/password authentication with encrypted passwords
- **User Profiles**: Create and manage your profile with name, year of study, and skills
- **Skill Management**: Add multiple skills you're proficient in
- **Skill Search**: Search for students by skill and connect via email
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## Tech Stack

### Frontend
- HTML5, CSS3, JavaScript (ES6+)
- Vite (Build tool and dev server)
- Supabase JS Client

### Backend
- Node.js + Express.js
- Supabase (PostgreSQL database)
- Supabase Auth (Authentication)

### Database
- PostgreSQL (via Supabase)
- Row Level Security (RLS) enabled
- Normalized schema with users and skills tables

## Project Structure

```
srm-skillx/
├── pages/
│   ├── login.html          # Login page
│   ├── register.html       # Registration page
│   ├── profile.html        # User profile management
│   └── search.html         # Skill search page
├── src/
│   ├── js/
│   │   ├── supabase.js     # Supabase client configuration
│   │   ├── register.js     # Registration logic
│   │   ├── login.js        # Login logic
│   │   ├── profile.js      # Profile management
│   │   └── search.js       # Search functionality
│   └── styles/
│       └── main.css        # Main stylesheet
├── server/
│   ├── config/
│   │   └── supabase.js     # Server-side Supabase config
│   ├── routes/
│   │   ├── auth.js         # Authentication routes
│   │   ├── profile.js      # Profile routes
│   │   └── skills.js       # Skills routes
│   └── index.js            # Express server
├── index.html              # Landing page
├── package.json
├── vite.config.js
└── README.md
```

## Database Schema

### Profiles Table
- `id` (UUID, Primary Key, links to auth.users)
- `name` (Text, Full name)
- `email` (Text, Unique, @srmp.edu.in)
- `year` (Text, Year of study: 1st/2nd/3rd/4th)
- `created_at` (Timestamp)
- `updated_at` (Timestamp)

### Skills Table
- `id` (UUID, Primary Key)
- `user_id` (UUID, Foreign Key to profiles)
- `skill_name` (Text, Name of the skill)
- `created_at` (Timestamp)

## Setup Instructions

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Supabase account

### 1. Clone the Repository
```bash
git clone <repository-url>
cd srm-skillx
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Set Up Environment Variables
The .env file should already be configured with your Supabase credentials. If not, copy the example file and fill in your Supabase credentials:

```bash
cp .env.example .env
```

Update the .env file with your Supabase credentials:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
PORT=3001
```

### 4. Database Setup
The database schema is already set up with the required tables and Row Level Security policies. No additional setup is needed.

### 5. Run the Application

#### Start the Backend Server (Terminal 1)
```bash
npm run server
```
The API server will run on http://localhost:3001

#### Start the Frontend Dev Server (Terminal 2)
```bash
npm run dev
```
The frontend will run on http://localhost:3000

### 6. Access the Application
Open your browser and navigate to:
```
http://localhost:3000
```

## Usage Guide

### 1. Registration
- Go to the Register page
- Enter your full name
- Use your SRM email (@srmp.edu.in)
- Create a secure password (minimum 6 characters)
- Click "Register"

### 2. Login
- Go to the Login page
- Enter your SRM email and password
- Click "Login"

### 3. Profile Management
- After logging in, you'll be redirected to your profile
- Update your name and year of study
- Add skills you're proficient in
- Remove skills you no longer want to share

### 4. Skill Search
- Navigate to the Search Skills page
- Enter a skill in the search box
- View results showing students with that skill
- Click "Contact via Email" to reach out

## Security Features

- **Email Domain Validation**: Only @srmp.edu.in emails are allowed
- **Password Hashing**: Passwords are securely hashed by Supabase Auth
- **Row Level Security**: Database access is controlled at the row level
- **Authentication Required**: Profile and skill management require authentication
- **Protected Routes**: Unauthorized users are redirected to login

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register a new user

### Profile
- `GET /api/profile/:userId` - Get user profile
- `PUT /api/profile/:userId` - Update user profile

### Skills
- `GET /api/skills/user/:userId` - Get user's skills
- `POST /api/skills` - Add a new skill
- `DELETE /api/skills/:skillId` - Delete a skill
- `GET /api/skills/search?query=skill` - Search skills

## Building for Production

```bash
npm run build
```

The production-ready files will be in the `dist` directory.

## Troubleshooting

### Port Already in Use
If port 3000 or 3001 is already in use, you can change them:
- Frontend: Edit `vite.config.js`
- Backend: Change PORT in `.env` file

### Database Connection Issues
- Verify your Supabase credentials in `.env`
- Check that your Supabase project is active
- Ensure Row Level Security policies are properly configured

### Authentication Issues
- Clear browser cache and cookies
- Verify email ends with @srmp.edu.in
- Check that Supabase Auth is enabled in your project

## Future Enhancements

- Skill categories and tags
- Direct messaging between users
- Skill ratings and reviews
- Advanced search filters
- User profile pictures
- Notification system

## License

This project is created for educational purposes as part of SRM University AP.

## Contact

For issues or questions, please contact the development team.
