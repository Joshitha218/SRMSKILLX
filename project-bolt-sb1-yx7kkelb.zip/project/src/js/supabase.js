import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export function showAlert(message, type = 'error') {
  const alertBox = document.getElementById('alertBox');
  if (alertBox) {
    alertBox.innerHTML = `
      <div class="alert alert-${type}">
        ${message}
      </div>
    `;
    setTimeout(() => {
      alertBox.innerHTML = '';
    }, 5000);
  }
}

export async function checkAuth() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}
