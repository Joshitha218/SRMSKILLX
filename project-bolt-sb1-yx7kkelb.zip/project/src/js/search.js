import { supabase, checkAuth } from './supabase.js';

let isLoggedIn = false;

async function init() {
  const session = await checkAuth();
  isLoggedIn = !!session;

  const navLinks = document.getElementById('navLinks');
  if (isLoggedIn) {
    navLinks.innerHTML = `
      <a href="/pages/profile.html" class="nav-link">Profile</a>
      <a href="/pages/search.html" class="nav-link">Search Skills</a>
    `;
  } else {
    navLinks.innerHTML = `
      <a href="/" class="nav-link">Home</a>
      <a href="/pages/login.html" class="nav-link">Login</a>
      <a href="/pages/register.html" class="nav-link btn-primary">Register</a>
    `;
  }
}

async function searchSkills(query) {
  const resultsContainer = document.getElementById('resultsContainer');

  if (!query.trim()) {
    resultsContainer.innerHTML = '';
    return;
  }

  resultsContainer.innerHTML = '<div class="loading">Searching...</div>';

  try {
    const { data: skills, error } = await supabase
      .from('skills')
      .select('*, profiles(*)')
      .ilike('skill_name', `%${query}%`);

    if (error) {
      resultsContainer.innerHTML = '<div class="no-results"><h3>Error searching skills</h3></div>';
      return;
    }

    if (skills.length === 0) {
      resultsContainer.innerHTML = `
        <div class="no-results">
          <h3>No results found</h3>
          <p>Try searching for a different skill</p>
        </div>
      `;
      return;
    }

    const uniqueUsers = new Map();
    skills.forEach((skill) => {
      const userId = skill.user_id;
      if (!uniqueUsers.has(userId)) {
        uniqueUsers.set(userId, {
          ...skill.profiles,
          skills: [],
        });
      }
      uniqueUsers.get(userId).skills.push(skill.skill_name);
    });

    const results = Array.from(uniqueUsers.values());

    resultsContainer.innerHTML = `
      <div class="results-grid">
        ${results
          .map(
            (user) => `
          <div class="result-card">
            <div class="result-header">
              <div class="result-info">
                <h3>${user.name || 'Anonymous'}</h3>
                <div class="result-meta">
                  ${user.year ? user.year + ' Year' : 'Year not specified'} • SRM University AP
                </div>
              </div>
              <a href="mailto:${user.email}" class="btn-contact">Contact via Email</a>
            </div>
            <div class="skills-list">
              ${user.skills
                .map((skill) => `<div class="skill-tag">${skill}</div>`)
                .join('')}
            </div>
          </div>
        `
          )
          .join('')}
      </div>
    `;
  } catch (error) {
    resultsContainer.innerHTML = '<div class="no-results"><h3>An error occurred</h3></div>';
  }
}

document.getElementById('searchBtn').addEventListener('click', () => {
  const query = document.getElementById('searchInput').value;
  searchSkills(query);
});

document.getElementById('searchInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    const query = document.getElementById('searchInput').value;
    searchSkills(query);
  }
});

init();
