import { supabase, showAlert, checkAuth } from './supabase.js';

let currentUser = null;

async function init() {
  const session = await checkAuth();
  if (!session) {
    window.location.href = '/pages/login.html';
    return;
  }

  currentUser = session.user;
  await loadProfile();
  await loadSkills();
}

async function loadProfile() {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', currentUser.id)
      .maybeSingle();

    if (error) {
      showAlert('Failed to load profile', 'error');
      return;
    }

    if (data) {
      document.getElementById('name').value = data.name || '';
      document.getElementById('email').value = data.email || '';
      document.getElementById('year').value = data.year || '';
    }
  } catch (error) {
    showAlert('An error occurred while loading profile', 'error');
  }
}

async function loadSkills() {
  try {
    const { data, error } = await supabase
      .from('skills')
      .select('*')
      .eq('user_id', currentUser.id);

    if (error) {
      showAlert('Failed to load skills', 'error');
      return;
    }

    const skillsList = document.getElementById('skillsList');
    if (data.length === 0) {
      skillsList.innerHTML = '<p style="color: #64748b;">No skills added yet. Add your first skill below!</p>';
      return;
    }

    skillsList.innerHTML = data
      .map(
        (skill) => `
        <div class="skill-tag">
          ${skill.skill_name}
          <button onclick="deleteSkill('${skill.id}')" aria-label="Remove skill">×</button>
        </div>
      `
      )
      .join('');
  } catch (error) {
    showAlert('An error occurred while loading skills', 'error');
  }
}

async function deleteSkill(skillId) {
  try {
    const { error } = await supabase
      .from('skills')
      .delete()
      .eq('id', skillId);

    if (error) {
      showAlert('Failed to delete skill', 'error');
      return;
    }

    await loadSkills();
    showAlert('Skill removed successfully', 'success');
  } catch (error) {
    showAlert('An error occurred while deleting skill', 'error');
  }
}

window.deleteSkill = deleteSkill;

document.getElementById('profileForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value.trim();
  const year = document.getElementById('year').value;

  try {
    const { error } = await supabase
      .from('profiles')
      .update({
        name,
        year,
        updated_at: new Date().toISOString(),
      })
      .eq('id', currentUser.id);

    if (error) {
      showAlert('Failed to update profile', 'error');
      return;
    }

    showAlert('Profile updated successfully', 'success');
  } catch (error) {
    showAlert('An error occurred while updating profile', 'error');
  }
});

document.getElementById('addSkillBtn').addEventListener('click', async () => {
  const skillInput = document.getElementById('newSkill');
  const skillName = skillInput.value.trim();

  if (!skillName) {
    showAlert('Please enter a skill name', 'error');
    return;
  }

  try {
    const { error } = await supabase
      .from('skills')
      .insert([
        {
          user_id: currentUser.id,
          skill_name: skillName,
        },
      ]);

    if (error) {
      showAlert('Failed to add skill', 'error');
      return;
    }

    skillInput.value = '';
    await loadSkills();
    showAlert('Skill added successfully', 'success');
  } catch (error) {
    showAlert('An error occurred while adding skill', 'error');
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  const { error } = await supabase.auth.signOut();
  if (!error) {
    window.location.href = '/';
  }
});

init();
