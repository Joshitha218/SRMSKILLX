import { showAlert } from './supabase.js';

const API_URL = 'http://localhost:3001/api';

document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  if (!email.endsWith('@srmp.edu.in')) {
    showAlert('Only SRM University AP students with @srmp.edu.in email can register', 'error');
    return;
  }

  if (password.length < 6) {
    showAlert('Password must be at least 6 characters long', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      showAlert(data.error || 'Registration failed', 'error');
      return;
    }

    showAlert('Registration successful! Redirecting to login...', 'success');
    setTimeout(() => {
      window.location.href = '/pages/login.html';
    }, 2000);
  } catch (error) {
    showAlert('An error occurred. Please try again.', 'error');
  }
});
