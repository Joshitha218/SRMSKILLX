import { supabase, showAlert } from './supabase.js';

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  if (!email.endsWith('@srmp.edu.in')) {
    showAlert('Only SRM University AP students with @srmp.edu.in email can login', 'error');
    return;
  }

  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      showAlert(error.message, 'error');
      return;
    }

    showAlert('Login successful! Redirecting...', 'success');
    setTimeout(() => {
      window.location.href = '/pages/profile.html';
    }, 1500);
  } catch (error) {
    showAlert('An error occurred. Please try again.', 'error');
  }
});
